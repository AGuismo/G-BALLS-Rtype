#include	<iostream>
#include	"ConsumerParser.hpp"
#include	"ProducterStream.hpp"

/*

  Sentence ::=	[[Blank]* Word]+ ['!'|'.'|'?']?

  Word ::=	['a'..'z' | 'A'..'Z']+

  Blank ::=	[' ' | 'TAB']

*/

/* INI

   File ::= Section*

   Section ::= SectionName Content

   SectionName ::= '[' identifier ']'

   Content ::= KeyVal*

   KeyVal ::= Key "=" Value

   Key ::= identifier

   Value ::= identifier | integer

 */

bool		readBlank(ConsumerParser &parser)
{
  parser.saveContext();
  while (parser.readChar(' ') || parser.readChar('\t'));
  return (true);
}

bool		readWord(ConsumerParser &parser)
{
  std::string	word;
  bool		ret = false;

  parser.beginCapture("word");
  while (parser.readRange('a', 'z') || parser.readRange('A', 'Z'))
    ret = true;
  if (ret)
    {
      parser.endCapture("word", word);
      std::cout << "My word is : {" << word << "}" << std::endl;
      std::cerr << "Read word success" << std::endl;
    }
  else
    std::cerr << "Read word failure" << std::endl;
  return (ret);
}

bool		readSentence(ConsumerParser &parser)
{
  if (readBlank(parser) && readWord(parser))
    {
      while (true)
	{
	  if (!(readBlank(parser) && readWord(parser)))
	    {
	      if (parser.readEOF() || parser.readChar('?') ||
		  parser.readChar('!') || parser.readChar('.'))
		  return (true);
	      return (false);
	    }
	}
    }
  return (false);
}

bool			readInt(ConsumerParser &pars)
{
  return (pars.readInteger());
}

bool			readIdentifier(ConsumerParser &pars)
{
  return (pars.readIdentifier());
}

int			main(int ac, char *av[])
{
  ProducterStream	prod;
  ConsumerParser	consumer(prod);

  prod.loadFile(av[1]);
  if (readSentence(consumer))
    std::cout << "My sentence is correct" << std::endl;
  else
    std::cout << "My sentence is not correct" << std::endl;
  return (0);
  // consumer.readUntilEOF();
  if (consumer.readEOF())
    std::cout << "My sentence is correct" << std::endl;
  else
    std::cout << "My sentence is not correct" << std::endl;
  return (0);
}
