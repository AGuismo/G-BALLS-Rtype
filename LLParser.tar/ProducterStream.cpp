#include	<iostream>
#include	<fstream>
#include	"ProducterStream.hpp"

//////////////////////////////////////////
//		Producter Class		//
//////////////////////////////////////////

ProducterStream::ProducterStream() :
  stream(0), type(NONE)
{

}

ProducterStream::~ProducterStream()
{
  if (type == FILE)
    delete this->stream;
}

bool		ProducterStream::loadFile(char *path)
{
  std::ifstream	*newStream;

  newStream = new std::ifstream(path);
  if (newStream->bad())
    {
      delete newStream;
      return (false);
    }
  if (type == FILE)
    delete stream;
  type = FILE;
  stream = newStream;
  return (true);
}

bool		ProducterStream::loadStdin()
{
  if (type == FILE)
    delete stream;
  stream = &std::cin;
  type = STDIN;
  return (true);
}

std::string	ProducterStream::nextString()
{
  char		extracted[maxReadBlock];

  if (type == NONE)
    throw std::runtime_error("Stream not initialized.");
  stream->read(extracted, maxReadBlock);
  if (stream->gcount() == 0)
    throw std::runtime_error("Stream is empty.");
  return (std::string(extracted, stream->gcount()));
}
