#ifndef CONSUMERSTREAM_H_
# define CONSUMERSTREAM_H_

#include	<iostream>


# include	<string>
# include	<stack>
# include	<map>

class ProducterStream;

class ConsumerParser
{
protected:
  typedef std::string::iterator		Context;
  typedef std::string::iterator		Capture;
  ProducterStream			&_stream;
  std::stack<Context>			_contexts;
  std::string				_inputData;
  bool					_isEOF;
  std::map<std::string, Capture>	_captures;

public:
  std::string::iterator			_rwHeader;

public:
  ConsumerParser(ProducterStream &);
  ~ConsumerParser();

private:
  bool		addData();

public:
  void		saveContext();
  void		restoreContext();
  inline bool	peekChar(char c);
  inline bool	readChar(char c);
  inline bool	readRange(char begin, char end);
  bool		readText(char *text);
  bool		readEOF();
  bool		readUntil(char c);
  bool		readUntilEOF();
  bool		readInteger();
  bool		readIdentifier();
  inline bool	beginCapture(std::string tag);
  inline bool	endCapture(std::string tag, std::string &out);

public:
  ConsumerParser(ConsumerParser const&);
  ConsumerParser& operator=(ConsumerParser const&);
};

inline bool	ConsumerParser::peekChar(char c)
{
  if (_rwHeader == _inputData.end() && !addData())
    {
      return (false);
    }
  if (*_rwHeader == c)
    return (true);
  return (false);
}

inline bool	ConsumerParser::readChar(char c)
{
  if (peekChar(c)) // He'll call addData()
    {
      _rwHeader++;
      return (true);
    }
  return (false);
}

inline bool	ConsumerParser::readRange(char begin, char end)
{
  saveContext();
  if (_rwHeader == _inputData.end() && !addData())
    {
      restoreContext();
      // std::cerr << "No more data" << std::endl;
      return (false);
    }
  // std::cout << "rwHeader pos : {" << *_rwHeader << "}" << std::endl;
  if (*_rwHeader >= begin && *_rwHeader <= end)
    {
      _rwHeader++;
      return (true);
    }
  restoreContext();
  return (false);
}

inline bool	ConsumerParser::beginCapture(std::string tag)
{
  _captures[tag] = _rwHeader;
}

inline bool	ConsumerParser::endCapture(std::string tag, std::string &out)
{
  if (_captures[tag] == _rwHeader)
    return (false);
  out = std::string(_captures[tag], _rwHeader);
  return (true);
}

#endif /* CONSUMERSTREAM_H_ */
