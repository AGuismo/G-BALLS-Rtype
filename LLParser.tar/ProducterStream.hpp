#ifndef PRODUCTERSTREAM_H_
# define PRODUCTERSTREAM_H_

# include	<string>
# include	<stdexcept>

class ProducterStream
{
public:
  static const short	maxReadBlock = 4096;
  std::istream		*stream;
  enum
    {
      FILE,
      STDIN,
      NONE
    }			type;

public:
  ProducterStream();
  ~ProducterStream();

private:
  ProducterStream(ProducterStream const&);
  ProducterStream&	operator=(ProducterStream const&);

public:
  std::string	nextString();
  bool		loadFile(char *path);
  bool		loadStdin();
};

#endif /* PRODUCTERSTREAM_H_ */
