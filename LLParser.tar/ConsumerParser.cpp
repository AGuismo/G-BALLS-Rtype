#include	<ctype.h>
#include	<cstring>
#include	<stdexcept>
#include	"ConsumerParser.hpp"
#include	"ProducterStream.hpp"

ConsumerParser::ConsumerParser(ProducterStream &stream) :
  _stream(stream), _isEOF(false)
{
  _inputData.reserve(1024);
  _rwHeader = _inputData.begin();
}

ConsumerParser::~ConsumerParser()
{

}

void	ConsumerParser::saveContext()
{
  // std::cout << "~~~ Save context at pos " << std::distance(_inputData.begin(), _rwHeader)
  // 	    << " (Character : {" << *_rwHeader << "})" << std::endl;
  _contexts.push(_rwHeader);
}

void	ConsumerParser::restoreContext()
{
  _rwHeader = _contexts.top();
  _contexts.pop();
  // std::cout << "~~~ Restore context at pos " << std::distance(_inputData.begin(), _rwHeader)
  // 	    << " (Character : {" << *_rwHeader << "})" << std::endl;
  _isEOF = _rwHeader == _inputData.end();
}

bool		ConsumerParser::addData()
{
  std::string	out;

  try
    {
      out = _stream.nextString();
    }
  catch (const std::runtime_error &e)
    {
      _isEOF = true;
      return (false);
    }
  _inputData += out;
  return (true);
}

bool		ConsumerParser::readText(char *text)
{
  saveContext();
  while (std::distance(_rwHeader, _inputData.end()) < ::strlen(text))
    {
      if (!addData())
	{
	  restoreContext();
	  return (false);
	}
    }
  if (std::string(_rwHeader, _rwHeader + ::strlen(text)) == text)
    {
      _rwHeader += ::strlen(text);
      return (true);
    }
  restoreContext();
  return (false);
}

bool		ConsumerParser::readEOF()
{
  peekChar(0);
  if (std::distance(_inputData.begin(), _rwHeader) == _inputData.size())
    return (true);
  return (_isEOF);
}

bool		ConsumerParser::readUntil(char c)
{
  if (_rwHeader == _inputData.end() && !addData())
    return (false);
  saveContext();
  while (*_rwHeader != c)
    {
      _rwHeader++;
      if (_rwHeader == _inputData.end() && !addData())
	{
	  restoreContext();
	  return (false);
	}
    }
  _rwHeader++;
  return (true);
}

bool		ConsumerParser::readUntilEOF()
{
  while (addData());
  _rwHeader = _inputData.end();
  return (true);
}

bool		ConsumerParser::readInteger()
{
  bool		isNum = false;

  saveContext();
  while (true)
    {
      if (_rwHeader == _inputData.end() && !addData())
	break;
      if (!std::isdigit(*_rwHeader))
      	break;
      isNum = true;
      _rwHeader++;
    }
  if (isNum)
    return (true);
  restoreContext();
  return (false);
}

bool		ConsumerParser::readIdentifier()
{
  if (_rwHeader == _inputData.end() && !addData())
      return (false);
  if (!(std::isalpha(*_rwHeader) || *_rwHeader == '_'))
      return (false);
  saveContext();
  ++_rwHeader;
  while (true)
    {
      if (_rwHeader == _inputData.end() && !addData())
	break;
      if (!(std::isalnum(*_rwHeader) || *_rwHeader == '_'))
	break;
      ++_rwHeader;
    }
  return (true);
}
